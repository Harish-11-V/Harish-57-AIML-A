# multi_api_integration.py - 3-API Integration System
# Integrates Octopart, Digi-Key, and Mouser APIs
# Based on corrected_excel.py

import requests
import json
from datetime import datetime, timedelta
import hashlib
import os
import urllib3

# Suppress SSL certificate warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================================================
# SMART CACHE SYSTEM - 30 Day TTL
# ============================================================================

class SmartCache:
    """30-day cache for component specifications"""
    
    def __init__(self, cache_dir=".component_cache"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
    def _get_cache_key(self, part_number):
        """Generate cache key from part number"""
        return hashlib.md5(part_number.encode()).hexdigest()
    
    def get(self, part_number):
        """Get cached data if not expired (30 days)"""
        cache_key = self._get_cache_key(part_number)
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
        
        if not os.path.exists(cache_file):
            return None
        
        try:
            with open(cache_file, 'r') as f:
                cached = json.load(f)
            
            # Check if expired (30 days)
            cached_time = datetime.fromisoformat(cached['timestamp'])
            if datetime.now() - cached_time > timedelta(days=30):
                print(f"   ⏰ Cache expired for {part_number}")
                return None
            
            print(f"   [OK] Using cached data for {part_number} (saved API call!)")
            return cached['data']
            
        except Exception as e:
            print(f"   [WARNING] Cache read error: {e}")
            return None
    
    def set(self, part_number, data):
        """Save data to cache"""
        cache_key = self._get_cache_key(part_number)
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
        
        try:
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'part_number': part_number,
                'data': data
            }
            
            with open(cache_file, 'w') as f:
                json.dump(cache_data, f, indent=2)
                
        except Exception as e:
            print(f"   [WARNING] Cache write error: {e}")


# ============================================================================
# OCTOPART (NEXAR) API CLIENT - WITH CACHING
# ============================================================================

class OctopartClient:
    """Octopart/Nexar API client with 30-day caching"""
    
    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = "https://identity.nexar.com/connect/token"
        self.api_url = "https://api.nexar.com/graphql"
        self.access_token = None
        self.cache = SmartCache()
        
    def get_access_token(self):
        """Get OAuth2 access token"""
        payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "supply.domain"
        }
        
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        
        try:
            response = requests.post(self.token_url, data=payload, headers=headers, verify=False)
            response.raise_for_status()
            result = response.json()
            self.access_token = result.get('access_token')
            return self.access_token
            
        except Exception as e:
            print(f"[ERROR] Nexar authentication error: {e}")
            return None
    
    def search_part_with_similar(self, part_number, limit=10):
        """Search for part and similar parts - WITH CACHING"""
        
        # Check cache first
        cached = self.cache.get(part_number)
        if cached:
            return cached
        
        print(f"\n[INFO] Searching Octopart for: {part_number}")
        
        if not self.access_token:
            self.get_access_token()
        
        query = """
        query SearchPart($q: String!, $limit: Int!) {
          supSearch(q: $q, limit: $limit) {
            results {
              part {
                mpn
                manufacturer {
                  name
                }
                category {
                  name
                }
                shortDescription
                specs {
                  attribute {
                    name
                  }
                  displayValue
                }
              }
            }
          }
        }
        """
        
        variables = {"q": part_number, "limit": limit}
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        payload = {"query": query, "variables": variables}
        
        try:
            response = requests.post(self.api_url, json=payload, headers=headers, verify=False)
            response.raise_for_status()
            result = response.json()
            
            if 'errors' in result:
                print(f"[ERROR] Octopart error: {result['errors']}")
                return []
            
            results = result.get('data', {}).get('supSearch', {}).get('results', [])
            parts = [r.get('part') for r in results if r.get('part')]
            
            print(f"   [OK] Found {len(parts)} parts from Octopart")
            
            # Cache the results for 30 days
            self.cache.set(part_number, parts)
            
            return parts
            
        except Exception as e:
            print(f"[ERROR] Octopart search error: {e}")
            return []


# ============================================================================
# DIGI-KEY API CLIENT
# ============================================================================

class DigiKeyClient:
    """Digi-Key API client"""
    
    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.access_token = None
        self.base_url = "https://api.digikey.com"
        
    def authenticate(self):
        """Get OAuth2 access token"""
        token_url = f"{self.base_url}/v1/oauth2/token"
        
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "client_credentials"
        }
        
        try:
            response = requests.post(token_url, data=data, verify=False)
            if response.status_code == 200:
                result = response.json()
                self.access_token = result.get("access_token")
                return True
            return False
        except:
            return False
    
    def search_part(self, part_number, record_count=10):
        """Search for part in Digi-Key and return products with DigiKey part numbers"""
        if not self.access_token:
            if not self.authenticate():
                return None
        
        print(f"   [INFO] Searching Digi-Key for: {part_number}...")
        
        url = f"{self.base_url}/products/v4/search/keyword"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "X-DIGIKEY-Client-Id": self.client_id,
            "Content-Type": "application/json"
        }
        payload = {
            "Keywords": part_number,
            "RecordCount": record_count,
            "RecordStartPosition": 0
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                products = data.get('Products', [])
                if products:
                    for product in products:
                        # v4 API: Check ProductVariations for DigiKey part numbers
                        variations = product.get('ProductVariations', [])
                        if variations:
                            # Get first variation's DigiKey part number
                            for var in variations:
                                dk_part_num = var.get('DigiKeyProductNumber', '') or var.get('DigiKeyPartNumber', '')
                                if dk_part_num:
                                    product['DigiKeyPartNumber'] = dk_part_num
                                    print(f"   [OK] Found Digi-Key part: {dk_part_num}")
                                    return product
                        
                        # Also check direct fields
                        dk_part_fields = ['DigiKeyPartNumber', 'DigiKeyProductNumber', 'ProductNumber']
                        for field in dk_part_fields:
                            dk_part_num = product.get(field, '')
                            if dk_part_num:
                                product['DigiKeyPartNumber'] = dk_part_num
                                print(f"   [OK] Found Digi-Key part: {dk_part_num}")
                                return product
                    
                    # If still not found, try first product's first variation
                    first_product = products[0]
                    variations = first_product.get('ProductVariations', [])
                    if variations:
                        first_var = variations[0]
                        # Get any available identifier
                        dk_part_num = (first_var.get('DigiKeyProductNumber', '') or 
                                      first_var.get('DigiKeyPartNumber', '') or
                                      first_var.get('ProductNumber', ''))
                        if dk_part_num:
                            first_product['DigiKeyPartNumber'] = dk_part_num
                            print(f"   [OK] Found Digi-Key part from variation: {dk_part_num}")
                            return first_product
                    
                    print(f"   [DEBUG] Product keys: {list(first_product.keys())}")
                    if variations:
                        print(f"   [DEBUG] Variation keys: {list(variations[0].keys()) if variations else 'N/A'}")
                    
                    print(f"   [WARNING] Found {len(products)} products but no part number")
                    return first_product
                else:
                    print(f"   [WARNING] No products found in Digi-Key for {part_number}")
            else:
                print(f"   [WARNING] Digi-Key search returned status {response.status_code}")
            return None
        except Exception as e:
            print(f"   [WARNING] Digi-Key search error: {e}")
            return None
    
    def get_alternate_packaging(self, product_number):
        """Get alternate packaging parts from Digi-Key API
        
        Args:
            product_number: Digi-Key product number
            
        Returns:
            List of alternate part numbers
        """
        if not self.access_token:
            if not self.authenticate():
                return []
        
        print(f"   [INFO] Fetching alternate packaging from Digi-Key for {product_number}...")
        
        url = f"{self.base_url}/products/v4/search/{product_number}/alternatepackaging"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "X-DIGIKEY-Client-Id": self.client_id,
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.get(url, headers=headers, verify=False)
            print(f"   [DEBUG] Alternate packaging response status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"   [DEBUG] Response keys: {list(data.keys())}")
                
                # Try multiple possible field names (v4 API uses 'AlternatePackagings')
                alternates = (data.get('AlternatePackagings', []) or 
                             data.get('AlternatePackaging', []) or 
                             data.get('alternatePackaging', []) or 
                             data.get('Products', []) or
                             data.get('ProductVariations', []))
                
                # v4 API: AlternatePackagings is a list containing dicts with 'AlternatePackaging' arrays
                part_numbers = []
                
                if alternates and len(alternates) > 0:
                    for alt_wrapper in alternates:
                        if isinstance(alt_wrapper, dict):
                            # Get nested AlternatePackaging array
                            nested_alts = alt_wrapper.get('AlternatePackaging', [])
                            for nested_alt in nested_alts:
                                if isinstance(nested_alt, dict):
                                    # Try to get DigiKey product number
                                    pn = (nested_alt.get('DigiKeyProductNumber', '') or
                                          nested_alt.get('DigiKeyPartNumber', '') or
                                          nested_alt.get('ProductNumber', ''))
                                    if pn:
                                        part_numbers.append(pn)
                
                if part_numbers:
                    print(f"   [OK] Found {len(part_numbers)} alternate packaging options: {part_numbers[:5]}")
                    return part_numbers
                else:
                    print(f"   [INFO] No alternate packaging options available")
            else:
                print(f"   [DEBUG] Response: {response.text[:200] if response.text else 'empty'}")
            return []
        except Exception as e:
            print(f"   [WARNING] Error fetching alternates: {e}")
            return []
    
    def get_part_details(self, product_number):
        """Get detailed part information including all parameters
        
        Args:
            product_number: Digi-Key product number
            
        Returns:
            Dict with part details and parameters
        """
        if not self.access_token:
            if not self.authenticate():
                return None
        
        print(f"   [INFO] Fetching detailed parameters for {product_number}...")
        
        url = f"{self.base_url}/products/v4/search/keyword"
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "X-DIGIKEY-Client-Id": self.client_id,
            "Content-Type": "application/json"
        }
        payload = {
            "Keywords": product_number,
            "RecordCount": 1,
            "RecordStartPosition": 0
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, verify=False)
            if response.status_code == 200:
                data = response.json()
                products = data.get('Products', [])
                if products:
                    product = products[0]
                    # Extract all parameters
                    parameters = {}
                    for param in product.get('Parameters', []):
                        param_name = param.get('ParameterText', '')
                        param_value = param.get('ValueText', '')
                        if param_name and param_value:
                            parameters[f'SPEC_{param_name}'] = param_value
                    
                    result = {
                        'MPN': product.get('ManufacturerPartNumber', ''),
                        'Manufacturer': product.get('Manufacturer', {}).get('Value', ''),
                        'Description': product.get('ProductDescription', ''),
                        'Category': product.get('ProductCategory', {}).get('Value', ''),
                        'DigiKeyPartNumber': product.get('DigiKeyPartNumber', ''),
                        **parameters
                    }
                    print(f"   [OK] Retrieved {len(parameters)} parameters from Digi-Key")
                    return result
            return None
        except Exception as e:
            print(f"   [WARNING] Error fetching part details: {e}")
            return None


# ============================================================================
# MOUSER API CLIENT - ALWAYS REAL-TIME
# ============================================================================

class MouserClient:
    """Mouser API client - real-time pricing/stock"""
    
    # Common manufacturer name variations
    MANUFACTURER_ALIASES = {
        'onsemi': 'ON Semiconductor',
        'on semiconductor': 'ON Semiconductor',
        'on semi': 'ON Semiconductor',
        'stmicroelectronics': 'STMicroelectronics',
        'st': 'STMicroelectronics',
        'stm': 'STMicroelectronics',
        'texas instruments': 'Texas Instruments',
        'ti': 'Texas Instruments',
        'analog devices': 'Analog Devices',
        'adi': 'Analog Devices',
        'maxim': 'Maxim Integrated',
        'maxim integrated': 'Maxim Integrated',
        'nxp': 'NXP Semiconductors',
        'nxp semiconductors': 'NXP Semiconductors',
        'infineon': 'Infineon Technologies',
        'infineon technologies': 'Infineon Technologies',
        'microchip': 'Microchip Technology',
        'microchip technology': 'Microchip Technology',
        'diodes': 'Diodes Incorporated',
        'diodes incorporated': 'Diodes Incorporated',
        'diodes inc': 'Diodes Incorporated',
        'renesas': 'Renesas Electronics',
        'renesas electronics': 'Renesas Electronics',
        'vishay': 'Vishay',
        'rohm': 'ROHM Semiconductor',
        'rohm semiconductor': 'ROHM Semiconductor',
        'toshiba': 'Toshiba',
        'panasonic': 'Panasonic',
        'murata': 'Murata',
        'yageo': 'Yageo',
        'kemet': 'KEMET',
        'avx': 'AVX',
        'kyocera': 'Kyocera',
        'bourns': 'Bourns',
        'littelfuse': 'Littelfuse',
        'samsung': 'Samsung',
        'fairchild': 'Fairchild Semiconductor',
        'fairchild semiconductor': 'Fairchild Semiconductor',
        'idt': 'IDT',
        'cypress': 'Cypress Semiconductor',
        'cypress semiconductor': 'Cypress Semiconductor',
        'freescale': 'Freescale Semiconductor',
        'freescale semiconductor': 'Freescale Semiconductor',
        'broadcom': 'Broadcom',
        'linear technology': 'Linear Technology',
        'lt': 'Linear Technology',
        'ltc': 'Linear Technology',
    }
    
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.mouser.com/api/v1"
    
    def normalize_manufacturer(self, manufacturer):
        """Normalize manufacturer name to Mouser's format"""
        if not manufacturer:
            return None
        mfr_lower = manufacturer.lower().strip()
        return self.MANUFACTURER_ALIASES.get(mfr_lower, manufacturer)
        
    def get_pricing_and_stock(self, part_number, manufacturer=None):
        """Get real-time pricing and stock - NO CACHING"""
        
        # Normalize manufacturer name
        normalized_mfr = self.normalize_manufacturer(manufacturer) if manufacturer else None
        
        if normalized_mfr:
            print(f"   [INFO] Getting pricing from Mouser for {normalized_mfr} {part_number}...")
        else:
            print(f"   [INFO] Getting pricing from Mouser...")
        
        url = f"{self.base_url}/search/partnumber?apiKey={self.api_key}"
        
        # Always search by part number only
        payload = {
            "SearchByPartRequest": {
                "mouserPartNumber": part_number,
                "partSearchOptions": ""
            }
        }
        
        headers = {
            "Content-Type": "application/json",
            "accept": "application/json"
        }
        
        try:
            response = requests.post(url, json=payload, headers=headers, verify=False)
            response.raise_for_status()
            result = response.json()
            
            parts = result.get('SearchResults', {}).get('Parts', [])
            
            if not parts:
                print(f"   [WARNING] No parts found in Mouser")
                return None
            
            # If manufacturer specified, find the exact match
            if normalized_mfr:
                normalized_lower = normalized_mfr.lower()
                
                for part in parts:
                    part_mfr = part.get('Manufacturer', '').strip().lower()
                    
                    # Check if manufacturer name contains our search term
                    if normalized_lower in part_mfr:
                        print(f"   [OK] Found match: {part.get('Manufacturer')}")
                        return part
                    
                    # Also check original manufacturer name (before normalization)
                    if manufacturer and manufacturer.lower() in part_mfr:
                        print(f"   [OK] Found match: {part.get('Manufacturer')}")
                        return part
                
                # No match found, use first result
                print(f"   [WARNING] '{normalized_mfr}' not found, using: {parts[0].get('Manufacturer', 'Unknown')}")
                return parts[0]
            else:
                # No manufacturer specified, return first result
                print(f"   [OK] Got pricing from Mouser")
                return parts[0]
            
        except Exception as e:
            print(f"   [WARNING] Mouser error: {e}")
            return None


# ============================================================================
# SMART DATA MERGER
# ============================================================================

class DataMerger:
    """Intelligently merge data from all 3 APIs"""
    
    @staticmethod
    def merge_part_data(octopart_data, digikey_data, mouser_data):
        """Merge data with priority rules"""
        merged = {}
        
        # Basic info from Octopart
        if octopart_data:
            merged['MPN'] = octopart_data.get('mpn', 'N/A')
            
            manufacturer = octopart_data.get('manufacturer', {})
            merged['Manufacturer'] = manufacturer.get('name', 'N/A') if manufacturer else 'N/A'
            
            merged['Description'] = octopart_data.get('shortDescription', 'N/A')
            
            category = octopart_data.get('category', {})
            merged['Category'] = category.get('name', 'N/A') if category else 'N/A'
            
            # All specifications from Octopart
            specs = octopart_data.get('specs', [])
            for spec in specs:
                attr = spec.get('attribute', {})
                attr_name = attr.get('name', 'Unknown')
                attr_value = spec.get('displayValue', 'N/A')
                merged[f"SPEC_{attr_name}"] = attr_value
        
        # Additional specs from Digi-Key if available
        if digikey_data:
            # Check if it's a dict with Parameters list (old format) or direct dict (new format)
            if isinstance(digikey_data, dict):
                if 'Parameters' in digikey_data:
                    # Old format: has Parameters list
                    parameters = digikey_data.get('Parameters', [])
                    for param in parameters:
                        param_name = param.get('ParameterText', 'Unknown')
                        param_value = param.get('ValueText', 'N/A')
                        spec_key = f"SPEC_{param_name}"
                        # Only add if not already present
                        if spec_key not in merged:
                            merged[spec_key] = param_value
                else:
                    # New format: direct dict with SPEC_ keys
                    for key, value in digikey_data.items():
                        if key.startswith('SPEC_') and key not in merged:
                            merged[key] = value
                    # Also copy basic fields if not present
                    if 'MPN' not in merged and digikey_data.get('MPN'):
                        merged['MPN'] = digikey_data.get('MPN')
                    if 'Manufacturer' not in merged and digikey_data.get('Manufacturer'):
                        merged['Manufacturer'] = digikey_data.get('Manufacturer')
                    if 'Description' not in merged and digikey_data.get('Description'):
                        merged['Description'] = digikey_data.get('Description')
                    if 'Category' not in merged and digikey_data.get('Category'):
                        merged['Category'] = digikey_data.get('Category')
        
        # Real-time pricing from Mouser (ALWAYS ADD)
        if mouser_data:
            merged['Mouser_PartNumber'] = mouser_data.get('MouserPartNumber', 'N/A')
            merged['Mouser_Stock'] = mouser_data.get('AvailabilityInStock', 'N/A')
            merged['Mouser_Availability'] = mouser_data.get('Availability', 'N/A')
            merged['Mouser_LeadTime'] = mouser_data.get('LeadTime', 'N/A')
            
            # Price breaks
            if mouser_data.get('PriceBreaks'):
                for pb in mouser_data['PriceBreaks']:
                    qty = pb.get('Quantity', '')
                    price = pb.get('Price', '')
                    currency = pb.get('Currency', '')
                    merged[f"Mouser_Price_Qty{qty}"] = f"{currency} {price}"
            
            merged['Mouser_DataSheet'] = mouser_data.get('DataSheetUrl', 'N/A')
            merged['Mouser_ProductURL'] = mouser_data.get('ProductDetailUrl', 'N/A')

        
        return merged


# ============================================================================
# MAIN INTEGRATION FUNCTION
# ============================================================================

def search_component_3api(octopart_id, octopart_secret, digikey_id, digikey_secret, 
                          mouser_key, part_number, manufacturer=None, limit=10):
    """Main integration function for 3-API search with Digi-Key alternate packaging"""
    
    print("="*80)
    print("3-API COMPONENT SEARCH INTEGRATION")
    print("Octopart (Specs) + Digi-Key (Alternates) + Mouser (Real-time Pricing)")
    print("="*80)
    
    # Initialize clients
    octopart = OctopartClient(octopart_id, octopart_secret)
    digikey = DigiKeyClient(digikey_id, digikey_secret) if digikey_id and digikey_secret else None
    mouser = MouserClient(mouser_key) if mouser_key else None
    
    merged_parts = []
    
    # Step 1: Get original part specs from Octopart (for reference)
    print(f"\n[STEP 1] Getting original part specs from Octopart: {part_number}...")
    octopart_parts = octopart.search_part_with_similar(part_number, limit=1)
    
    original_octopart_data = None
    original_mpn = part_number
    manufacturer_name = manufacturer or ''
    
    if octopart_parts:
        original_octopart_data = octopart_parts[0]
        original_mpn = original_octopart_data.get('mpn', part_number)
        if original_octopart_data.get('manufacturer'):
            manufacturer_name = original_octopart_data.get('manufacturer', {}).get('name', manufacturer_name)
        print(f"[OK] Found original part: {original_mpn} ({manufacturer_name})")
    else:
        print(f"[INFO] Part not found in Octopart, continuing with Digi-Key...")
    
    # Step 2: Search Digi-Key for the part and get alternate packaging
    if digikey:
        print(f"\n[STEP 2] Searching Digi-Key for: {original_mpn}...")
        
        digikey_product = digikey.search_part(original_mpn)
        
        if digikey_product:
            digikey_part_number = digikey_product.get('DigiKeyPartNumber', '')
            
            if digikey_part_number:
                print(f"[OK] Found Digi-Key part number: {digikey_part_number}")
                
                # Add original part first
                print(f"\n[STEP 3] Getting original part details from Digi-Key...")
                original_digikey_data = digikey.get_part_details(digikey_part_number)
                if original_digikey_data:
                    mouser_data = None
                    if mouser:
                        mouser_data = mouser.get_pricing_and_stock(
                            original_digikey_data.get('MPN', original_mpn),
                            original_digikey_data.get('Manufacturer', manufacturer_name)
                        )
                    merged_original = DataMerger.merge_part_data(original_octopart_data, original_digikey_data, mouser_data)
                    merged_parts.append(merged_original)
                    print(f"[OK] Added original part: {original_digikey_data.get('MPN', original_mpn)}")
                
                # Get alternate packaging from Digi-Key API
                print(f"\n[STEP 4] Fetching alternate packaging from Digi-Key API...")
                print(f"   URL: api.digikey.com/products/v4/search/{digikey_part_number}/alternatepackaging")
                
                alternate_part_numbers = digikey.get_alternate_packaging(digikey_part_number)
                
                if alternate_part_numbers:
                    print(f"[OK] Found {len(alternate_part_numbers)} alternate packaging options from Digi-Key")
                    
                    # Fetch details for each alternate part
                    print(f"\n[STEP 5] Fetching parameters for each alternate part...")
                    
                    max_alternates = min(len(alternate_part_numbers), limit - 1)
                    for idx, alt_part_num in enumerate(alternate_part_numbers[:max_alternates], 1):
                        print(f"\n   [{idx}/{max_alternates}] Fetching: {alt_part_num}")
                        alt_data = digikey.get_part_details(alt_part_num)
                        if alt_data:
                            # Get Mouser pricing
                            mouser_data = None
                            if mouser:
                                mouser_data = mouser.get_pricing_and_stock(
                                    alt_data.get('MPN', alt_part_num), 
                                    alt_data.get('Manufacturer', '')
                                )
                            
                            merged_alt = DataMerger.merge_part_data(None, alt_data, mouser_data)
                            merged_parts.append(merged_alt)
                            print(f"   [OK] Added: {alt_data.get('MPN', alt_part_num)} (DigiKey: {alt_part_num})")
                else:
                    print("[INFO] No alternate packaging found from Digi-Key API")
            else:
                print("[WARNING] Digi-Key product found but no DigiKeyPartNumber")
                # Add the original part with Octopart data
                if original_octopart_data:
                    mouser_data = None
                    if mouser:
                        mouser_data = mouser.get_pricing_and_stock(original_mpn, manufacturer_name)
                    merged = DataMerger.merge_part_data(original_octopart_data, digikey_product, mouser_data)
                    merged_parts.append(merged)
        else:
            print("[WARNING] Part not found in Digi-Key")
            # Add original from Octopart if available
            if original_octopart_data:
                mouser_data = None
                if mouser:
                    mouser_data = mouser.get_pricing_and_stock(original_mpn, manufacturer_name)
                merged = DataMerger.merge_part_data(original_octopart_data, None, mouser_data)
                merged_parts.append(merged)
    else:
        print("[WARNING] Digi-Key not configured")
        # Add original from Octopart
        if original_octopart_data:
            mouser_data = None
            if mouser:
                mouser_data = mouser.get_pricing_and_stock(original_mpn, manufacturer_name)
            merged = DataMerger.merge_part_data(original_octopart_data, None, mouser_data)
            merged_parts.append(merged)
    
    print(f"\n[SUCCESS] Total parts collected: {len(merged_parts)}")
    if merged_parts:
        print(f"   Original: {merged_parts[0].get('MPN', 'N/A')}")
        print(f"   Alternates from Digi-Key: {len(merged_parts) - 1}")
    
    return merged_parts


def _process_octopart_parts(octopart_parts, mouser, default_manufacturer=None):
    """Process Octopart parts with optional Mouser pricing"""
    merged_parts = []
    
    for idx, part in enumerate(octopart_parts):
        mpn = part.get('mpn', 'N/A')
        manufacturer = part.get('manufacturer', {})
        manufacturer_name = manufacturer.get('name', default_manufacturer) if manufacturer else default_manufacturer
        
        print(f"   [{idx+1}/{len(octopart_parts)}] Processing: {mpn} ({manufacturer_name})")
        
        # Get Mouser pricing if available
        mouser_data = None
        if mouser:
            mouser_data = mouser.get_pricing_and_stock(mpn, manufacturer_name)
        
        merged = DataMerger.merge_part_data(part, None, mouser_data)
        merged_parts.append(merged)
    
    return merged_parts



