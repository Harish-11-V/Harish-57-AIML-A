"""
Gemini-based color coding using FFF (Form, Fit, Function) validation
"""
import os
import json
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import Dict, List, Any, Union
import google.generativeai as genai


def load_fff_prompt():
    """Load FFF system prompt from file"""
    try:
        with open('fff_system_prompt.md', 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return """You are an expert Component Engineer performing FFF (Form, Fit, Function) validation for electronic component replacement.

## Validation Rules:
- MATCH: Parameter matches exactly or within acceptable tolerance
- IMPROVED: Candidate parameter is better than EOL (higher rating, wider range)
- MINOR_DIFFERENCE: Small difference that is acceptable
- CRITICAL_FAILURE: Parameter does not meet EOL requirement
- UNKNOWN: Unable to determine due to missing or unclear data"""


def normalize_priority_map(priority_map: Union[List[Dict], List[Any]]) -> List[Dict]:
    """Convert priority_map to List[Dict] regardless of input type"""
    normalized = []
    for item in priority_map:
        if hasattr(item, 'dict'):
            # Pydantic model
            normalized.append(item.dict())
        elif hasattr(item, 'parameter') and hasattr(item, 'priority'):
            # Object with attributes
            normalized.append({
                'parameter': item.parameter,
                'priority': item.priority
            })
        elif isinstance(item, dict):
            normalized.append(item)
        else:
            # Try to convert
            normalized.append(dict(item))
    return normalized


def analyze_with_gemini_fff(eol_specs: Dict, candidate_specs: Dict, priority_map: List[Dict], gemini_api_key: str) -> Dict:
    """Use Gemini AI with FFF prompt to perform color coding decisions"""
    if not gemini_api_key:
        return None
    
    try:
        genai.configure(api_key=gemini_api_key)
        
        # Load FFF prompt
        fff_prompt = load_fff_prompt()
        
        # Build priority text
        priority_text = "\n".join([
            f"- {p.get('parameter', p.get('name', 'Unknown'))}: Priority {p.get('priority', 2)} "
            f"({'Must Match' if p.get('priority', 2) == 1 else 'Can Differ' if p.get('priority', 2) == 2 else 'Cosmetic'})"
            for p in priority_map
        ]) if priority_map else "No specific priorities defined - use default FFF rules"
        
        # Build specs text - clean up parameter names
        def clean_param(k):
            return k.replace('SPEC_', '').strip()
        
        eol_text = "\n".join([
            f"- {clean_param(k)}: {v}" 
            for k, v in eol_specs.items() 
            if v not in [None, '', 'Not Available', 'N/A', '-']
        ])
        
        candidate_text = "\n".join([
            f"- {clean_param(k)}: {v}" 
            for k, v in candidate_specs.items() 
            if v not in [None, '', 'Not Available', 'N/A', '-']
        ])
        
        # Build the comparison prompt
        user_prompt = f"""{fff_prompt}

---
COMPARISON REQUEST:

## EOL Part Specifications:
{eol_text if eol_text else "No specifications available"}

## Candidate Part Specifications:
{candidate_text if candidate_text else "No specifications available"}

## User Priority Map:
{priority_text}

---
INSTRUCTIONS:
1. Compare each parameter between EOL and Candidate parts
2. Apply FFF validation rules and priority considerations
3. Return ONLY valid JSON (no markdown, no explanation outside JSON)

Return this exact JSON structure:
{{
  "comparison_matrix": [
    {{
      "parameter": "parameter_name",
      "eol_value": "value1",
      "candidate_value": "value2",
      "ai_status": "MATCH",
      "reasoning": "explanation"
    }}
  ],
  "overall_status": "MATCH"
}}

Valid ai_status values: "MATCH", "IMPROVED", "MINOR_DIFFERENCE", "CRITICAL_FAILURE", "UNKNOWN"
Valid overall_status values: "MATCH", "IMPROVED", "MINOR_DIFFERENCE", "CRITICAL_FAILURE"
"""
        
        # Use gemini-2.5-flash which has fresh quota pool
        model = genai.GenerativeModel(model_name="gemini-2.5-flash")
        response = model.generate_content(user_prompt)
        
        # Parse JSON from response
        response_text = response.text.strip()
        
        # Remove markdown code blocks if present
        if "```json" in response_text:
            response_text = response_text.split("```json")[1].split("```")[0]
        elif "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
        
        # Clean up response
        response_text = response_text.strip()
        
        # Parse JSON
        result = json.loads(response_text)
        
        print(f"[OK] Gemini analysis completed - {len(result.get('comparison_matrix', []))} parameters analyzed")
        return result
    
    except json.JSONDecodeError as e:
        print(f"[WARNING] Gemini response JSON parse error: {e}")
        print(f"[DEBUG] Response text: {response_text[:500] if 'response_text' in dir() else 'N/A'}")
        return None
    except Exception as e:
        print(f"[WARNING] Gemini FFF analysis error: {e}")
        return None


def apply_gemini_color_coding_to_excel(
    input_file: str, 
    output_file: str, 
    eol_part_data: Dict, 
    priority_map: Union[List[Dict], List[Any]], 
    gemini_api_key: str
):
    """
    Apply Gemini-based color coding to Excel using FFF validation
    
    Args:
        input_file: Path to input Excel file
        output_file: Path to output Excel file
        eol_part_data: Dictionary with EOL part specifications
        priority_map: List of priority mappings (Pydantic models or dicts)
        gemini_api_key: Gemini API key
    """
    
    print("=" * 80)
    print("APPLYING GEMINI FFF COLOR CODING TO EXCEL")
    print("=" * 80)
    
    # Normalize priority_map to List[Dict]
    normalized_priority = normalize_priority_map(priority_map) if priority_map else []
    print(f"[INFO] Priority map: {len(normalized_priority)} parameters")
    
    # Load the workbook
    print(f"\n[LOADING] File: {input_file}")
    wb = load_workbook(input_file)
    ws = wb.active
    
    # Define color fills
    yellow_fill = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")  # Header
    gray_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")        # Attribute column
    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")       # Match/Improved
    light_green_fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid") # Improved
    orange_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")      # Minor difference
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")         # Critical failure
    
    # Define fonts and alignment
    bold_font = Font(bold=True, size=11)
    header_font = Font(bold=True, size=14)
    left_align = Alignment(horizontal='left', vertical='center', wrap_text=True)
    center_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Get dimensions
    max_row = ws.max_row
    max_col = ws.max_column
    
    print(f"[INFO] Excel dimensions: {max_row} rows x {max_col} columns")
    
    # Structure: Row 1=Title, Row 2=Subtitle, Row 3=Headers, Row 4+=Data
    title_row = 1
    header_row = 3
    data_start_row = 4
    
    # Read attribute names and reference values (EOL part - column B)
    print("\n[INFO] Reading EOL part reference values...")
    reference_values = {}
    attribute_rows = {}  # Map attribute name to row index
    
    for row_idx in range(data_start_row, max_row + 1):
        attribute_cell = ws.cell(row=row_idx, column=1)
        attribute_name = attribute_cell.value
        if attribute_name and not str(attribute_name).startswith('==='):
            ref_cell = ws.cell(row=row_idx, column=2)
            reference_values[attribute_name] = ref_cell.value
            attribute_rows[attribute_name] = row_idx
    
    print(f"[OK] Found {len(reference_values)} attributes")
    
    # Apply title formatting
    title_cell = ws.cell(row=title_row, column=1)
    title_cell.font = header_font
    title_cell.alignment = center_align
    
    # Apply formatting to headers (row 3)
    for col_idx in range(2, max_col + 1):
        cell = ws.cell(row=header_row, column=col_idx)
        cell.fill = yellow_fill
        cell.font = bold_font
        cell.alignment = center_align
        cell.border = thin_border
    
    # Apply gray to attribute column (column A)
    for row_idx in range(header_row, max_row + 1):
        cell = ws.cell(row=row_idx, column=1)
        cell.fill = gray_fill
        cell.font = bold_font
        cell.alignment = left_align
        cell.border = thin_border
    
    # Statistics
    comparison_stats = {
        'match': 0,
        'improved': 0,
        'minor_difference': 0,
        'critical_failure': 0,
        'unknown': 0
    }
    
    # Apply green to EOL reference column (column B) - always green
    print("\n[INFO] Coloring EOL reference column (always green)...")
    for row_idx in range(data_start_row, max_row + 1):
        attribute_cell = ws.cell(row=row_idx, column=1)
        attribute_name = attribute_cell.value
        if attribute_name and not str(attribute_name).startswith('==='):
            cell = ws.cell(row=row_idx, column=2)
            cell.fill = green_fill
            cell.alignment = left_align
            cell.border = thin_border
    
    # Process each candidate part (columns 3+)
    num_candidates = max_col - 2
    print(f"\n[INFO] Processing {num_candidates} candidate parts with Gemini FFF...")
    
    for col_idx in range(3, max_col + 1):
        candidate_num = col_idx - 2
        print(f"\n[CANDIDATE {candidate_num}/{num_candidates}] Analyzing...")
        
        # Build candidate specs dictionary
        candidate_specs = {}
        for row_idx in range(data_start_row, max_row + 1):
            attribute_cell = ws.cell(row=row_idx, column=1)
            attribute_name = attribute_cell.value
            if attribute_name and not str(attribute_name).startswith('==='):
                cell = ws.cell(row=row_idx, column=col_idx)
                # Use SPEC_ prefix for consistency
                spec_key = f'SPEC_{attribute_name}' if not str(attribute_name).startswith('SPEC_') else attribute_name
                candidate_specs[spec_key] = cell.value
        
        # Get Gemini analysis for this candidate
        gemini_result = analyze_with_gemini_fff(
            eol_part_data, 
            candidate_specs, 
            normalized_priority, 
            gemini_api_key
        )
        
        if gemini_result:
            # Create mapping from Gemini results - handle various parameter name formats
            gemini_map = {}
            for item in gemini_result.get('comparison_matrix', []):
                param = item.get('parameter', '')
                status = item.get('ai_status', 'UNKNOWN').upper()
                
                # Store with multiple key formats for matching
                gemini_map[param] = status
                gemini_map[param.replace('SPEC_', '')] = status
                gemini_map[f'SPEC_{param}'] = status
                # Also try lowercase matching
                gemini_map[param.lower()] = status
                gemini_map[param.replace('SPEC_', '').lower()] = status
            
            # Apply colors based on Gemini analysis
            for row_idx in range(data_start_row, max_row + 1):
                attribute_cell = ws.cell(row=row_idx, column=1)
                attribute_name = attribute_cell.value
                
                if not attribute_name or str(attribute_name).startswith('==='):
                    continue
                
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.alignment = left_align
                cell.border = thin_border
                
                # Get Gemini status for this parameter - try multiple name formats
                status = (
                    gemini_map.get(attribute_name) or
                    gemini_map.get(str(attribute_name).lower()) or
                    gemini_map.get(f'SPEC_{attribute_name}') or
                    gemini_map.get(str(attribute_name).replace('SPEC_', '')) or
                    'UNKNOWN'
                )
                
                # Apply color based on status
                if status == 'MATCH':
                    cell.fill = green_fill
                    comparison_stats['match'] += 1
                elif status == 'IMPROVED':
                    cell.fill = light_green_fill  # Lighter green for improved
                    comparison_stats['improved'] += 1
                elif status == 'MINOR_DIFFERENCE':
                    cell.fill = orange_fill
                    comparison_stats['minor_difference'] += 1
                elif status == 'CRITICAL_FAILURE':
                    cell.fill = red_fill
                    comparison_stats['critical_failure'] += 1
                else:  # UNKNOWN
                    # Check if value is missing
                    if cell.value in [None, '', 'Not Available', 'N/A', '-']:
                        cell.fill = red_fill
                        comparison_stats['critical_failure'] += 1
                    else:
                        cell.fill = orange_fill
                        comparison_stats['unknown'] += 1
            
            print(f"[OK] Candidate {candidate_num} - Overall: {gemini_result.get('overall_status', 'N/A')}")
        
        else:
            # Fallback: use simple string comparison if Gemini fails
            print(f"[WARNING] Gemini analysis failed for candidate {candidate_num}, using fallback comparison")
            
            for row_idx in range(data_start_row, max_row + 1):
                attribute_cell = ws.cell(row=row_idx, column=1)
                attribute_name = attribute_cell.value
                
                if not attribute_name or str(attribute_name).startswith('==='):
                    continue
                
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.alignment = left_align
                cell.border = thin_border
                
                reference_value = reference_values.get(attribute_name)
                current_value = cell.value
                
                # Simple fallback comparison
                if current_value in [None, '', 'Not Available', 'N/A', '-']:
                    cell.fill = red_fill
                    comparison_stats['critical_failure'] += 1
                elif reference_value in [None, '', 'Not Available', 'N/A', '-']:
                    cell.fill = orange_fill
                    comparison_stats['unknown'] += 1
                elif str(reference_value).strip().lower() == str(current_value).strip().lower():
                    cell.fill = green_fill
                    comparison_stats['match'] += 1
                else:
                    cell.fill = orange_fill
                    comparison_stats['minor_difference'] += 1
    
    # Adjust column widths
    print("\n[INFO] Adjusting column widths...")
    ws.column_dimensions['A'].width = 35
    for col_idx in range(2, max_col + 1):
        col_letter = get_column_letter(col_idx)
        ws.column_dimensions[col_letter].width = 25
    
    # Adjust row heights
    ws.row_dimensions[title_row].height = 30
    ws.row_dimensions[header_row].height = 30
    
    # Save
    print(f"\n[SAVING] To: {output_file}")
    wb.save(output_file)
    wb.close()
    
    # Print statistics
    print("\n" + "=" * 80)
    print("[SUCCESS] GEMINI FFF COLOR CODING APPLIED!")
    print("=" * 80)
    print(f"\nColor Coding Statistics:")
    print(f"  [GREEN]  Match:          {comparison_stats['match']} cells")
    print(f"  [GREEN+] Improved:       {comparison_stats['improved']} cells")
    print(f"  [ORANGE] Minor Diff:     {comparison_stats['minor_difference']} cells")
    print(f"  [RED]    Critical:       {comparison_stats['critical_failure']} cells")
    print(f"  [GRAY]   Unknown:        {comparison_stats['unknown']} cells")
    
    total = sum(comparison_stats.values())
    if total > 0:
        match_rate = ((comparison_stats['match'] + comparison_stats['improved']) / total) * 100
        print(f"\n  Match/Improved Rate: {match_rate:.1f}%")
    
    print(f"\n[OK] Output file: {output_file}")
    print("=" * 80)


if __name__ == "__main__":
    # Test standalone
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python colour_gemini.py <input_file> <output_file> [gemini_api_key]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    api_key = sys.argv[3] if len(sys.argv) > 3 else os.getenv("GEMINI_API_KEY", "")
    
    if not api_key:
        print("Error: GEMINI_API_KEY not provided")
        sys.exit(1)
    
    # Mock EOL data and priority map for testing
    eol_data = {}
    priority = []
    
    apply_gemini_color_coding_to_excel(input_file, output_file, eol_data, priority, api_key)
