"""
Test script for Gemini-based Excel color coding
Creates a sample Excel with candidate parts for testing
"""
import os
from dotenv import load_dotenv
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

# Load environment variables
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in .env file")
    print("Please add GEMINI_API_KEY=your_api_key to .env")
    exit(1)

print("=" * 60)
print("TESTING GEMINI COLOR CODING")
print("=" * 60)

# Create test Excel with multiple candidates
def create_test_excel():
    """Create a test Excel file with EOL and candidate parts"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Comparison"
    
    # Row 1: Title
    ws['A1'] = "Component Comparison Report - LM317T (Test)"
    ws['A1'].font = Font(bold=True, size=14)
    ws.merge_cells('A1:D1')
    
    # Row 2: Subtitle
    ws['A2'] = "Generated for testing"
    ws['A2'].font = Font(italic=True, size=9)
    ws.merge_cells('A2:D2')
    
    # Row 3: Headers
    headers = ['Attribute', 'Original (LM317T)', 'Similar 1 (LM317L)', 'Similar 2 (LM350T)']
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=3, column=col, value=header)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center')
    
    # Data rows (Row 4+)
    data = [
        # [Attribute, Original, Similar1, Similar2]
        ['ManufacturerPartNumber', 'LM317T', 'LM317L', 'LM350T'],
        ['Manufacturer', 'Texas Instruments', 'Texas Instruments', 'Texas Instruments'],
        ['Description', 'Adjustable Voltage Regulator', 'Low Power Voltage Regulator', 'High Current Voltage Regulator'],
        ['SPEC_Voltage - Input (Max)', '40V', '40V', '35V'],
        ['SPEC_Voltage - Output (Min/Fixed)', '1.25V', '1.25V', '1.25V'],
        ['SPEC_Voltage - Output (Max)', '37V', '37V', '33V'],
        ['SPEC_Current - Output', '1.5A', '100mA', '3A'],
        ['SPEC_Operating Temperature', '-40C to 125C', '-40C to 125C', '0C to 125C'],
        ['SPEC_Package / Case', 'TO-220-3', 'TO-92-3', 'TO-220-3'],
        ['SPEC_Mounting Type', 'Through Hole', 'Through Hole', 'Through Hole'],
        ['SPEC_Output Type', 'Adjustable', 'Adjustable', 'Adjustable'],
        ['SPEC_Dropout Voltage', '2V', '2V', '2.5V'],
        ['SPEC_PSRR', '65dB', 'Not Available', '60dB'],
        ['Price_Qty1', '$0.75', '$0.45', '$1.25'],
        ['Stock_Mouser', '15000', '8500', '3200'],
    ]
    
    for row_idx, row_data in enumerate(data, 4):
        for col_idx, value in enumerate(row_data, 1):
            ws.cell(row=row_idx, column=col_idx, value=value)
    
    # Adjust column widths
    ws.column_dimensions['A'].width = 35
    ws.column_dimensions['B'].width = 25
    ws.column_dimensions['C'].width = 25
    ws.column_dimensions['D'].width = 25
    
    test_file = "reports/test_comparison.xlsx"
    os.makedirs("reports", exist_ok=True)
    wb.save(test_file)
    wb.close()
    print(f"[OK] Created test file: {test_file}")
    return test_file


# Create test file
input_file = create_test_excel()
output_file = "reports/test_comparison_GEMINI_COLORED.xlsx"

print(f"\nInput file:  {input_file}")
print(f"Output file: {output_file}")

# Import the module
from colour_gemini import apply_gemini_color_coding_to_excel

# Sample EOL part data (LM317T specs)
eol_part_data = {
    "SPEC_Voltage - Input (Max)": "40V",
    "SPEC_Voltage - Output (Min/Fixed)": "1.25V",
    "SPEC_Voltage - Output (Max)": "37V",
    "SPEC_Current - Output": "1.5A",
    "SPEC_Operating Temperature": "-40C to 125C",
    "SPEC_Package / Case": "TO-220-3",
    "SPEC_Mounting Type": "Through Hole",
    "SPEC_Output Type": "Adjustable",
    "SPEC_Dropout Voltage": "2V",
    "SPEC_PSRR": "65dB",
}

# Sample priority map
priority_map = [
    {"parameter": "Voltage - Input (Max)", "priority": 1},
    {"parameter": "Voltage - Output (Min/Fixed)", "priority": 1},
    {"parameter": "Current - Output", "priority": 1},
    {"parameter": "Package / Case", "priority": 1},
    {"parameter": "Operating Temperature", "priority": 2},
    {"parameter": "Mounting Type", "priority": 2},
    {"parameter": "Output Type", "priority": 2},
    {"parameter": "Dropout Voltage", "priority": 3},
    {"parameter": "PSRR", "priority": 3},
]

print(f"\nEOL specs: {len(eol_part_data)} parameters")
print(f"Priority map: {len(priority_map)} parameters")
print("\n" + "-" * 60)

# Apply color coding
try:
    apply_gemini_color_coding_to_excel(
        input_file,
        output_file,
        eol_part_data,
        priority_map,
        GEMINI_API_KEY
    )
    print("\n" + "=" * 60)
    print("TEST COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print(f"\nOpen the output file to verify colors:")
    print(f"  {os.path.abspath(output_file)}")
    print("\nExpected colors:")
    print("  - LM317L: Some RED (low current), some GREEN (matching specs)")
    print("  - LM350T: Some GREEN (higher current=IMPROVED), some ORANGE (temp range)")
except Exception as e:
    import traceback
    print(f"\nTEST FAILED: {e}")
    traceback.print_exc()
