import React from 'react';
import Dashboard from '../components/Dashboard';

function Analysis() {
  return <Dashboard />;
}

export default Analysis;

