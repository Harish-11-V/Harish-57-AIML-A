import React from 'react';
import { FiUser, FiMail, FiShield, FiBriefcase, FiClock } from 'react-icons/fi';
import './Profile.css';

function Profile() {
  const user = {
    name: 'Harish M',
    email: 'harish.m@ltts.com',
    role: 'Administrator',
    department: 'Engineering R&D',
    joinDate: 'January 2024',
    avatar: null
  };

  return (
    <div className="profile-container">
      <div className="profile-header glass-panel">
        <div className="profile-cover"></div>
        <div className="profile-main-info">
          <div className="profile-avatar-xl">
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} />
            ) : (
              <span>{user.name.split(' ').map(n => n[0]).join('')}</span>
            )}
          </div>
          <div className="profile-title">
            <h1>{user.name}</h1>
            <span className="role-badge">{user.role}</span>
          </div>
        </div>
      </div>

      <div className="profile-grid">
        <div className="card profile-card">
          <h3>Personal Information</h3>
          <div className="info-list">
            <div className="info-item">
              <FiUser className="info-icon" />
              <div>
                <label>Full Name</label>
                <p>{user.name}</p>
              </div>
            </div>
            <div className="info-item">
              <FiMail className="info-icon" />
              <div>
                <label>Email Address</label>
                <p>{user.email}</p>
              </div>
            </div>
            <div className="info-item">
              <FiBriefcase className="info-icon" />
              <div>
                <label>Department</label>
                <p>{user.department}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="card profile-card">
          <h3>Account Details</h3>
          <div className="info-list">
            <div className="info-item">
              <FiShield className="info-icon" />
              <div>
                <label>Role & Permissions</label>
                <p>{user.role} - Full Access</p>
              </div>
            </div>
            <div className="info-item">
              <FiClock className="info-icon" />
              <div>
                <label>Member Since</label>
                <p>{user.joinDate}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;
