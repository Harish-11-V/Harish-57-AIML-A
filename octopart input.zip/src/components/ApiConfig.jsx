import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiKey, FiChevronRight, FiAlertCircle, FiCheckCircle, FiInfo } from 'react-icons/fi';
import './ApiConfig.css';

const API_BASE_URL = 'http://localhost:8001';

function ApiConfig() {
  const [apiKeys, setApiKeys] = useState({
    octopartClientId: '',
    octopartClientSecret: '',
    geminiApiKey: '',
    digikeyClientId: '',
    digikeyClientSecret: '',
    mouserApiKey: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [validating, setValidating] = useState(false);
  const navigate = useNavigate();

  // Check if user is authenticated
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    if (!isAuthenticated) {
      navigate('/login', { replace: true });
    }

    // Load saved API keys if available
    const savedKeys = localStorage.getItem('apiKeys');
    if (savedKeys) {
      try {
        const parsed = JSON.parse(savedKeys);
        setApiKeys(prev => ({ ...prev, ...parsed }));
      } catch (e) {
        console.error('Failed to load saved API keys');
      }
    }
  }, [navigate]);

  const handleInputChange = (field, value) => {
    setApiKeys(prev => ({
      ...prev,
      [field]: value
    }));
    setError('');
  };

  const validateAndSaveApiKeys = async () => {
    // Check required fields (Octopart is mandatory)
    if (!apiKeys.octopartClientId.trim() || !apiKeys.octopartClientSecret.trim()) {
      setError('Octopart Client ID and Secret are required');
      return;
    }

    setValidating(true);
    setError('');

    try {
      // Send API keys to backend for validation and storage
      const response = await fetch(`${API_BASE_URL}/api/v1/configure_api_keys`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          octopart_client_id: apiKeys.octopartClientId.trim(),
          octopart_client_secret: apiKeys.octopartClientSecret.trim(),
          gemini_api_key: apiKeys.geminiApiKey.trim() || null,
          digikey_client_id: apiKeys.digikeyClientId.trim() || null,
          digikey_client_secret: apiKeys.digikeyClientSecret.trim() || null,
          mouser_api_key: apiKeys.mouserApiKey.trim() || null
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Failed to configure API keys');
      }

      // Save session ID and keys to localStorage
      localStorage.setItem('sessionId', data.session_id);
      localStorage.setItem('apiKeys', JSON.stringify(apiKeys));
      localStorage.setItem('apiConfigured', 'true');
      localStorage.setItem('configuredApis', JSON.stringify(data.configured_apis));

      // Navigate to dashboard
      navigate('/dashboard');
    } catch (err) {
      setError(err.message || 'Failed to validate API keys');
    } finally {
      setValidating(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    validateAndSaveApiKeys();
  };

  const handleSkip = () => {
    // Allow skip but warn that features will be limited
    localStorage.setItem('apiConfigured', 'false');
    navigate('/dashboard');
  };

  return (
    <div className="api-config-container">
      <div className="api-config-card">
        <div className="api-config-header">
          <div className="api-icon-badge">
            <FiKey size={32} />
          </div>
          <h1>API Configuration</h1>
          <p className="api-config-subtitle">
            Configure your API credentials to enable component search and analysis
          </p>
        </div>

        <form onSubmit={handleSubmit} className="api-config-form">
          {/* Required Section */}
          <div className="api-section">
            <div className="section-header required">
              <h3>Required - Octopart/Nexar API</h3>
              <span className="badge badge-required">Required</span>
            </div>
            <p className="section-description">
              Octopart provides component specifications and alternative parts data.
              <a href="https://nexar.com/api" target="_blank" rel="noopener noreferrer"> Get API keys</a>
            </p>

            <div className="form-group">
              <label htmlFor="octopartClientId">Client ID *</label>
              <input
                id="octopartClientId"
                type="text"
                value={apiKeys.octopartClientId}
                onChange={(e) => handleInputChange('octopartClientId', e.target.value)}
                placeholder="Enter Octopart/Nexar Client ID"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="octopartClientSecret">Client Secret *</label>
              <input
                id="octopartClientSecret"
                type="password"
                value={apiKeys.octopartClientSecret}
                onChange={(e) => handleInputChange('octopartClientSecret', e.target.value)}
                placeholder="Enter Octopart/Nexar Client Secret"
                required
              />
            </div>
          </div>

          {/* Optional Section - Gemini */}
          <div className="api-section">
            <div className="section-header optional">
              <h3>Optional - Google Gemini AI</h3>
              <span className="badge badge-optional">Optional</span>
            </div>
            <p className="section-description">
              Enables AI-powered FFF (Form, Fit, Function) analysis for better recommendations.
            </p>

            <div className="form-group">
              <label htmlFor="geminiApiKey">API Key</label>
              <input
                id="geminiApiKey"
                type="password"
                value={apiKeys.geminiApiKey}
                onChange={(e) => handleInputChange('geminiApiKey', e.target.value)}
                placeholder="Enter Gemini API Key (optional)"
              />
            </div>
          </div>

          {/* Optional Section - Digi-Key */}
          <div className="api-section">
            <div className="section-header optional">
              <h3>Optional - Digi-Key API</h3>
              <span className="badge badge-optional">Optional</span>
            </div>
            <p className="section-description">
              Adds real-time pricing and availability from Digi-Key.
            </p>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="digikeyClientId">Client ID</label>
                <input
                  id="digikeyClientId"
                  type="text"
                  value={apiKeys.digikeyClientId}
                  onChange={(e) => handleInputChange('digikeyClientId', e.target.value)}
                  placeholder="Digi-Key Client ID"
                />
              </div>

              <div className="form-group">
                <label htmlFor="digikeyClientSecret">Client Secret</label>
                <input
                  id="digikeyClientSecret"
                  type="password"
                  value={apiKeys.digikeyClientSecret}
                  onChange={(e) => handleInputChange('digikeyClientSecret', e.target.value)}
                  placeholder="Digi-Key Client Secret"
                />
              </div>
            </div>
          </div>

          {/* Optional Section - Mouser */}
          <div className="api-section">
            <div className="section-header optional">
              <h3>Optional - Mouser API</h3>
              <span className="badge badge-optional">Optional</span>
            </div>
            <p className="section-description">
              Adds real-time pricing and availability from Mouser.
            </p>

            <div className="form-group">
              <label htmlFor="mouserApiKey">API Key</label>
              <input
                id="mouserApiKey"
                type="password"
                value={apiKeys.mouserApiKey}
                onChange={(e) => handleInputChange('mouserApiKey', e.target.value)}
                placeholder="Enter Mouser API Key"
              />
            </div>
          </div>

          {error && (
            <div className="api-error">
              <FiAlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          <div className="api-config-actions">
            <button
              type="button"
              className="btn-skip"
              onClick={handleSkip}
              disabled={validating}
            >
              Skip for Now
            </button>
            <button
              type="submit"
              className="btn-continue"
              disabled={validating || !apiKeys.octopartClientId || !apiKeys.octopartClientSecret}
            >
              {validating ? 'Validating...' : 'Continue to Dashboard'}
              <FiChevronRight size={18} />
            </button>
          </div>

          <div className="api-info-note">
            <FiInfo size={16} />
            <span>Your API keys are stored securely in your session and are never persisted on the server.</span>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ApiConfig;
