from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Dict, Optional
import os
import sys
from datetime import datetime
import google.generativeai as genai
from dotenv import load_dotenv
import uuid

# Fix encoding for Windows
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Import Octopart API and color coding
from octopartapi import OctopartAPI
from colour import apply_color_coding_to_excel
from excelwriter import ExcelWriter
from multi_api_integration import search_component_3api

# Load environment variables (for backwards compatibility)
load_dotenv()

app = FastAPI(title="L&T-CORe - Component Obsolescence & Resilience Engine")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Session-based credential storage (in-memory)
# In production, use Redis or a proper session store
user_sessions: Dict[str, Dict] = {}

# Pydantic models for API key configuration
class ApiKeyConfig(BaseModel):
    octopart_client_id: str
    octopart_client_secret: str
    gemini_api_key: Optional[str] = None
    digikey_client_id: Optional[str] = None
    digikey_client_secret: Optional[str] = None
    mouser_api_key: Optional[str] = None

class ApiKeyConfigResponse(BaseModel):
    success: bool
    session_id: str
    message: str
    configured_apis: Dict[str, bool]

class PriorityMap(BaseModel):
    parameter: str
    priority: int

class AnalyzeRequest(BaseModel):
    eol_part_number: str
    manufacturer: Optional[str] = None
    priority_map: List[PriorityMap]

class PartSpec(BaseModel):
    parameter: str
    value: str

class EOLSpecResponse(BaseModel):
    part_number: str
    specs: List[PartSpec]


# Helper function to get credentials from session
def get_session_credentials(session_id: str) -> Optional[Dict]:
    if not session_id or session_id not in user_sessions:
        return None
    return user_sessions.get(session_id)


# Helper function to create OctopartAPI instance for a session
def get_octopart_api_for_session(session_id: str):
    creds = get_session_credentials(session_id)
    if not creds:
        return None
    client_id = creds.get('octopart_client_id')
    client_secret = creds.get('octopart_client_secret')
    if client_id and client_secret:
        return OctopartAPI(client_id, client_secret)
    return None


print("=" * 60)
print("L&T-CORe Backend - Session-Based API Configuration")
print("=" * 60)
print("Users will provide their own API keys at login")
print("=" * 60)


@app.get("/")
async def root():
    return {"message": "L&T-CORe - Component Obsolescence & Resilience Engine API"}


@app.post("/api/v1/configure_api_keys", response_model=ApiKeyConfigResponse)
async def configure_api_keys(config: ApiKeyConfig):
    """Configure API keys for the current session.

    This endpoint receives API credentials from the user and validates them.
    Returns a session_id that must be used in subsequent API calls.
    """
    try:
        # Validate Octopart credentials by attempting to create an API instance
        try:
            test_api = OctopartAPI(config.octopart_client_id, config.octopart_client_secret)
            # Optionally, you could do a test query here to verify credentials
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid Octopart credentials: {str(e)}"
            )

        # Generate a unique session ID
        session_id = str(uuid.uuid4())

        # Store credentials in session
        user_sessions[session_id] = {
            'octopart_client_id': config.octopart_client_id,
            'octopart_client_secret': config.octopart_client_secret,
            'gemini_api_key': config.gemini_api_key,
            'digikey_client_id': config.digikey_client_id,
            'digikey_client_secret': config.digikey_client_secret,
            'mouser_api_key': config.mouser_api_key,
            'created_at': datetime.now().isoformat()
        }

        # Build configured APIs status
        configured_apis = {
            'octopart': True,
            'gemini': bool(config.gemini_api_key),
            'digikey': bool(config.digikey_client_id and config.digikey_client_secret),
            'mouser': bool(config.mouser_api_key)
        }

        print(f"[INFO] New session created: {session_id[:8]}...")
        print(f"[INFO] Configured APIs: {configured_apis}")

        return ApiKeyConfigResponse(
            success=True,
            session_id=session_id,
            message="API keys configured successfully",
            configured_apis=configured_apis
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Configuration failed: {str(e)}")


@app.get("/api/v1/session_status")
async def session_status(x_session_id: Optional[str] = Header(None)):
    """Check if the current session is valid and return configured APIs."""
    if not x_session_id or x_session_id not in user_sessions:
        return {
            "valid": False,
            "message": "No valid session. Please configure API keys."
        }

    creds = user_sessions[x_session_id]
    return {
        "valid": True,
        "configured_apis": {
            'octopart': bool(creds.get('octopart_client_id')),
            'gemini': bool(creds.get('gemini_api_key')),
            'digikey': bool(creds.get('digikey_client_id') and creds.get('digikey_client_secret')),
            'mouser': bool(creds.get('mouser_api_key'))
        }
    }


@app.get("/api/v1/lookup_eol_specs/{part_number}")
async def lookup_eol_specs(
    part_number: str,
    manufacturer: str = None,
    x_session_id: Optional[str] = Header(None)
):
    """Lookup EOL part specifications from Octopart

    Args:
        part_number: Part number to search for
        manufacturer: Optional manufacturer name to prioritize
        x_session_id: Session ID from API configuration (passed via header)
    """
    # Get Octopart API for this session
    octopart_api = get_octopart_api_for_session(x_session_id)

    if not octopart_api:
        raise HTTPException(
            status_code=401,
            detail="API not configured. Please configure your Octopart API credentials first."
        )

    try:
        # Small limit to reduce API usage (EOL + up to 2 alternatives for lookup)
        recommendations = octopart_api.search_similar_parts(part_number, limit=3)
        if not recommendations:
            raise HTTPException(status_code=404, detail=f"No parts found for {part_number}")

        eol_part = recommendations[0]
        specs: List[PartSpec] = []
        for key, value in eol_part.items():
            if key not in ['_internal_id', '_source']:
                specs.append(PartSpec(parameter=key, value=str(value)))

        return EOLSpecResponse(part_number=part_number, specs=specs)

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Error fetching specs: {str(e)}")


@app.post("/api/v1/download_report")
async def download_report(
    request: AnalyzeRequest,
    x_session_id: Optional[str] = Header(None)
):
    """Generate and download color-coded Excel report using 3-API integration.

    Uses Octopart (cached 30 days) + Digi-Key + Mouser (real-time pricing).
    Falls back to Octopart-only if other APIs are not configured.
    """
    try:
        # Get credentials for this session
        creds = get_session_credentials(x_session_id)
        if not creds:
            raise HTTPException(
                status_code=401,
                detail="API not configured. Please configure your API credentials first."
            )

        # Extract credentials
        OCTOPART_CLIENT_ID = creds.get('octopart_client_id', '')
        OCTOPART_CLIENT_SECRET = creds.get('octopart_client_secret', '')
        DIGIKEY_CLIENT_ID = creds.get('digikey_client_id', '')
        DIGIKEY_CLIENT_SECRET = creds.get('digikey_client_secret', '')
        MOUSER_API_KEY = creds.get('mouser_api_key', '')
        GEMINI_API_KEY = creds.get('gemini_api_key', '')

        # Get Octopart API for this session
        octopart_api = get_octopart_api_for_session(x_session_id)

        if not octopart_api:
            raise HTTPException(status_code=401, detail="Octopart API not configured")

        eol_part_number = request.eol_part_number

        # Try 3-API integration first (if Digi-Key and/or Mouser are configured)
        merged_parts = []

        if DIGIKEY_CLIENT_ID or MOUSER_API_KEY:
            # Use 3-API integration
            print(f"\n[INFO] Using 3-API integration (Octopart + Digi-Key + Mouser)")
            manufacturer_name = request.manufacturer if request.manufacturer else None
            merged_parts = search_component_3api(
                octopart_id=OCTOPART_CLIENT_ID,
                octopart_secret=OCTOPART_CLIENT_SECRET,
                digikey_id=DIGIKEY_CLIENT_ID,
                digikey_secret=DIGIKEY_CLIENT_SECRET,
                mouser_key=MOUSER_API_KEY,
                part_number=eol_part_number,
                manufacturer=manufacturer_name,
                limit=5  # Set to 5 alternatives as requested
            )

            if not merged_parts:
                raise HTTPException(status_code=404, detail="No parts found from 3-API integration")
        else:
            # Fallback to Octopart-only
            print(f"\n[INFO] Using Octopart-only (Digi-Key/Mouser not configured)")
            recommendations = octopart_api.search_similar_parts(eol_part_number, limit=5)
            if not recommendations:
                raise HTTPException(status_code=404, detail="No parts found from Octopart")

            # Convert to merged format
            for rec in recommendations:
                merged = {}
                merged['MPN'] = rec.get('ManufacturerPartNumber', rec.get('MPN', 'N/A'))
                merged['Manufacturer'] = rec.get('Manufacturer', 'N/A')
                merged['Description'] = rec.get('Description', rec.get('ShortDescription', 'N/A'))
                merged['Category'] = rec.get('Category', 'N/A')

                # Add all specs
                for key, value in rec.items():
                    if key not in ['ManufacturerPartNumber', 'MPN', 'Manufacturer', 'Description',
                                  'ShortDescription', 'Category', '_internal_id', '_source']:
                        if not key.startswith('SPEC_'):
                            merged[f'SPEC_{key}'] = value
                        else:
                            merged[key] = value

                merged_parts.append(merged)

        # Create Excel with ExcelWriter (includes color coding)
        excel_writer = ExcelWriter()
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        temp_filename = f"EOL_Alternatives_{eol_part_number}_{timestamp}.xlsx"
        temp_filepath = os.path.join("reports", temp_filename)

        # Ensure reports directory exists
        os.makedirs("reports", exist_ok=True)

        # Use the new create_comparison method directly
        temp_file = temp_filepath.replace('.xlsx', '_temp.xlsx')
        excel_writer.create_comparison(
            parts_data=merged_parts,
            filename=temp_file,
            original_part=eol_part_number
        )

        # Apply color coding with Gemini FFF validation
        final_file = temp_filepath
        try:
            import time
            time.sleep(0.5)

            # Try Gemini color coding first if available
            if GEMINI_API_KEY and merged_parts:
                try:
                    from colour_gemini import apply_gemini_color_coding_to_excel

                    # Extract EOL part data (first part) - include all specs
                    eol_part_data = {}
                    for key, value in merged_parts[0].items():
                        if key.startswith('SPEC_'):
                            eol_part_data[key] = value
                        elif key not in ['MPN', 'Manufacturer', 'Description', 'Category', '_internal_id', '_source']:
                            # Also include non-SPEC parameters
                            eol_part_data[f'SPEC_{key}'] = value

                    # Convert priority_map to list of dicts
                    priority_list = [p.dict() for p in request.priority_map] if request.priority_map else []

                    print(f"\n[INFO] Applying Gemini FFF color coding...")
                    print(f"[INFO] EOL specs: {len(eol_part_data)} parameters")
                    print(f"[INFO] Priority map: {len(priority_list)} parameters")

                    apply_gemini_color_coding_to_excel(
                        temp_file,
                        final_file,
                        eol_part_data,
                        priority_list,
                        GEMINI_API_KEY
                    )
                except ImportError:
                    print(f"[WARNING] Gemini color coding module not found, using standard color coding")
                    apply_color_coding_to_excel(temp_file, final_file)
                except Exception as e:
                    import traceback
                    print(f"[WARNING] Gemini color coding failed: {e}")
                    traceback.print_exc()
                    print("[INFO] Falling back to standard color coding")
                    apply_color_coding_to_excel(temp_file, final_file)
            else:
                # Fallback to standard color coding
                apply_color_coding_to_excel(temp_file, final_file)

            # Clean up temp file
            if os.path.exists(temp_file):
                max_retries = 3
                for attempt in range(max_retries):
                    try:
                        time.sleep(0.3)
                        os.remove(temp_file)
                        break
                    except PermissionError:
                        if attempt < max_retries - 1:
                            time.sleep(0.5)
                else:
                    print(f"[WARNING] Could not delete temp file")
        except Exception as e:
            print(f"[WARNING] Color coding failed: {e}")
            if os.path.exists(temp_file):
                import time
                max_retries = 3
                for attempt in range(max_retries):
                    try:
                        time.sleep(0.3)
                        if os.path.exists(final_file):
                            os.remove(final_file)
                        os.rename(temp_file, final_file)
                        break
                    except (PermissionError, OSError):
                        if attempt < max_retries - 1:
                            time.sleep(0.5)

        # Return the color-coded file
        return FileResponse(
            path=final_file,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=os.path.basename(final_file)
        )

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Report generation failed: {str(e)}")


async def analyze_with_gemini(eol_specs: Dict, candidate_specs: Dict, priority_map: List[Dict], gemini_api_key: str) -> Dict:
    """Use Gemini AI to perform FFF validation and color coding decisions"""
    if not gemini_api_key:
        # Fallback without Gemini
        return fallback_comparison(eol_specs, candidate_specs)

    try:
        # Configure Gemini with the user's API key
        genai.configure(api_key=gemini_api_key)

        # Build prompt
        priority_text = "\n".join([
            f"- {p['parameter']}: Priority {p['priority']} "
            f"({'Must Match' if p['priority'] == 1 else 'Can Differ' if p['priority'] == 2 else 'Cosmetic'})"
            for p in priority_map
        ])

        eol_text = "\n".join([f"- {k}: {v}" for k, v in eol_specs.items() if not k.startswith('_')])
        candidate_text = "\n".join([f"- {k}: {v}" for k, v in candidate_specs.items() if not k.startswith('_')])

        user_prompt = f"""
Compare these electronic component specifications and determine color coding:

EOL Part Specifications:
{eol_text}

Candidate Part Specifications:
{candidate_text}

User Priority Map:
{priority_text}

For each parameter, determine the color:
- "MATCH" (Green): Exact match or functionally equivalent
- "VARIATION" (Yellow): Slight variation that may be acceptable
- "NO_MATCH" (Red): Significant difference or missing data

Return JSON format:
{{
  "comparison_matrix": [
    {{
      "parameter": "parameter_name",
      "eol_value": "value1",
      "candidate_value": "value2",
      "ai_status": "MATCH" | "VARIATION" | "NO_MATCH",
      "reasoning": "explanation"
    }}
  ],
  "overall_status": "MATCH" | "VARIATION" | "NO_MATCH"
}}
"""

        model = genai.GenerativeModel(model_name="gemini-1.5-flash")
        response = model.generate_content(user_prompt)

        # Parse JSON from response
        response_text = response.text
        if "```json" in response_text:
            response_text = response_text.split("```json")[1].split("```")[0]
        elif "```" in response_text:
            response_text = response_text.split("```")[1].split("```")[0]

        import json
        result = json.loads(response_text.strip())
        return result

    except Exception as e:
        print(f"Gemini API error: {e}")
        return fallback_comparison(eol_specs, candidate_specs)


def fallback_comparison(eol_specs: Dict, candidate_specs: Dict) -> Dict:
    """Fallback comparison without Gemini"""
    comparison = []
    all_params = set(eol_specs.keys()) | set(candidate_specs.keys())

    for param in all_params:
        if param.startswith('_'):
            continue

        eol_val = str(eol_specs.get(param, "N/A"))
        cand_val = str(candidate_specs.get(param, "N/A"))

        if eol_val == cand_val and eol_val != "N/A":
            status = "MATCH"
        elif eol_val != "N/A" and cand_val != "N/A":
            status = "VARIATION"
        else:
            status = "NO_MATCH"

        comparison.append({
            "parameter": param,
            "eol_value": eol_val,
            "candidate_value": cand_val,
            "ai_status": status,
            "reasoning": "Automatic comparison"
        })

    return {
        "comparison_matrix": comparison,
        "overall_status": "VARIATION"
    }


if __name__ == "__main__":
    import uvicorn
    print("=" * 60)
    print("Starting L&T-CORe - Component Obsolescence & Resilience Engine")
    print("=" * 60)
    print("Session-based API key management enabled")
    print("Users will provide their own API credentials at login")
    print("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8001)
